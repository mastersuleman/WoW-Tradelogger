-- TradeLogger.lua
-- Version 12 - Fixed trade detection for WoTLK
-- Compatible with WoW 3.3.5

TradeLoggerDB = TradeLoggerDB or { trades = {}, trackGold = true, trackItems = true }

local frame = CreateFrame("Frame")
frame:RegisterEvent("TRADE_SHOW")
frame:RegisterEvent("TRADE_PLAYER_ITEM_CHANGED")
frame:RegisterEvent("TRADE_TARGET_ITEM_CHANGED")
frame:RegisterEvent("TRADE_ACCEPT_UPDATE")
frame:RegisterEvent("TRADE_CLOSED")

local currentTrade = { playerItems = {}, playerGold = 0, targetItems = {}, targetGold = 0, targetName = "Unknown" }
local completedTrade = nil  -- Store the completed trade data
local tradePartner = nil
local playerAccepted = false
local targetAccepted = false
local tradeWasCompleted = false  -- Track if both players accepted at any point

-- Get player name
local playerName = UnitName("player")

-- Debug function (can be commented out when not needed)
local function DebugPrint(msg)
    -- DEFAULT_CHAT_FRAME:AddMessage("|cFF808080[TL Debug]: " .. msg .. "|r")
end

-- Save current trade state
local function SaveTradeState()
    if not TradeLoggerDB then
        TradeLoggerDB = { trades = {}, trackGold = true, trackItems = true }
    end
    
    -- Get target name - try multiple methods
    if TradeFrameRecipientNameText and TradeFrameRecipientNameText:GetText() then
        tradePartner = TradeFrameRecipientNameText:GetText()
        -- Remove "Trade with " prefix if present
        tradePartner = string.gsub(tradePartner, "Trade with ", "")
    else
        tradePartner = UnitName("NPC") or UnitName("target") or "Unknown"
    end
    
    currentTrade.targetName = tradePartner
    DebugPrint("Trading with: " .. tradePartner)
    
    -- Save gold
    if TradeLoggerDB.trackGold then
        currentTrade.playerGold = GetPlayerTradeMoney() or 0
        currentTrade.targetGold = GetTargetTradeMoney() or 0
    end
    
    -- Save items
    if TradeLoggerDB.trackItems then
        currentTrade.playerItems = {}
        currentTrade.targetItems = {}
        
        for i = 1, 7 do
            -- Skip the "Will not be traded" slot (slot 7)
            if i < 7 then
                -- Get player items (what you're giving)
                local itemLink = GetTradePlayerItemLink(i)
                if itemLink then
                    local _, _, count = GetTradePlayerItemInfo(i)
                    count = count or 1
                    if count > 1 then
                        currentTrade.playerItems[i] = itemLink .. " x" .. count
                    else
                        currentTrade.playerItems[i] = itemLink
                    end
                    DebugPrint("Player item slot " .. i .. ": " .. currentTrade.playerItems[i])
                end
            end
            
            -- Get target items (what you're receiving)
            local targetLink = GetTradeTargetItemLink(i)
            if targetLink then
                local _, _, count = GetTradeTargetItemInfo(i)
                count = count or 1
                if count > 1 then
                    currentTrade.targetItems[i] = targetLink .. " x" .. count
                else
                    currentTrade.targetItems[i] = targetLink
                end
                DebugPrint("Target item slot " .. i .. ": " .. currentTrade.targetItems[i])
            end
        end
    end
end

-- Record completed trade
local function RecordTrade()
    if not TradeLoggerDB then
        TradeLoggerDB = { trades = {}, trackGold = true, trackItems = true }
    end
    if not TradeLoggerDB.trades then
        TradeLoggerDB.trades = {}
    end
    
    -- Use the saved completed trade data if available, otherwise use current
    local tradeToRecord = completedTrade or currentTrade
    
    -- Check if anything was actually traded
    local hasPlayerItems = false
    local hasTargetItems = false
    
    for _, item in pairs(tradeToRecord.playerItems) do
        if item then hasPlayerItems = true break end
    end
    for _, item in pairs(tradeToRecord.targetItems) do
        if item then hasTargetItems = true break end
    end
    
    local hasPlayerGold = tradeToRecord.playerGold and tradeToRecord.playerGold > 0
    local hasTargetGold = tradeToRecord.targetGold and tradeToRecord.targetGold > 0
    
    DebugPrint("Has player items: " .. tostring(hasPlayerItems) .. ", Has target items: " .. tostring(hasTargetItems))
    DebugPrint("Player gold: " .. (tradeToRecord.playerGold or 0) .. ", Target gold: " .. (tradeToRecord.targetGold or 0))
    
    -- Only log if something was actually traded
    if hasPlayerItems or hasTargetItems or hasPlayerGold or hasTargetGold then
        local timeStamp = date("%m/%d %H:%M")
        
        table.insert(TradeLoggerDB.trades, 1, {
            time = timeStamp,
            target = tradeToRecord.targetName,
            playerItems = tradeToRecord.playerItems,
            playerGold = tradeToRecord.playerGold,
            targetItems = tradeToRecord.targetItems,
            targetGold = tradeToRecord.targetGold,
            playerName = playerName
        })
        
        -- Keep only last 100 trades
        if #TradeLoggerDB.trades > 100 then
            table.remove(TradeLoggerDB.trades, #TradeLoggerDB.trades)
        end
        
        -- Simple notification in chat
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD700TradeLogger:|r Trade logged with " .. tradeToRecord.targetName .. " - type |cFF00FF00/tradelog|r to view", 1, 0.8, 0)
        DebugPrint("Trade recorded successfully!")
    else
        DebugPrint("Nothing traded, not recording")
    end
end

-- Event handler
frame:SetScript("OnEvent", function(self, event, arg1, arg2)
    DebugPrint("Event: " .. event .. ", arg1: " .. tostring(arg1) .. ", arg2: " .. tostring(arg2))
    
    if event == "TRADE_SHOW" then
        -- Reset trade state
        currentTrade = { playerItems = {}, playerGold = 0, targetItems = {}, targetGold = 0, targetName = "Unknown" }
        completedTrade = nil  -- Clear any previous completed trade
        playerAccepted = false
        targetAccepted = false
        tradeWasCompleted = false  -- Reset completion flag
        SaveTradeState()
        
    elseif event == "TRADE_PLAYER_ITEM_CHANGED" or event == "TRADE_TARGET_ITEM_CHANGED" then
        -- Update trade state when items change
        SaveTradeState()
        
    elseif event == "TRADE_ACCEPT_UPDATE" then
        -- Check accept status
        playerAccepted = arg1 == 1
        targetAccepted = arg2 == 1
        
        DebugPrint("Player accepted: " .. tostring(playerAccepted) .. ", Target accepted: " .. tostring(targetAccepted))
        
        -- Save state when either party accepts
        SaveTradeState()
        
        -- If both accepted, mark trade as completed and save the trade data
        if playerAccepted and targetAccepted then
            DebugPrint("Both players accepted - trade should complete")
            tradeWasCompleted = true  -- Mark that trade was completed
            -- Make a copy of the current trade data before it gets cleared
            completedTrade = {
                playerItems = {},
                playerGold = currentTrade.playerGold,
                targetItems = {},
                targetGold = currentTrade.targetGold,
                targetName = currentTrade.targetName
            }
            -- Deep copy the items
            for k, v in pairs(currentTrade.playerItems) do
                completedTrade.playerItems[k] = v
            end
            for k, v in pairs(currentTrade.targetItems) do
                completedTrade.targetItems[k] = v
            end
            DebugPrint("Saved trade data for completion")
        end
        
    elseif event == "TRADE_CLOSED" then
        -- Trade window closed - check if trade was completed
        -- In WoTLK, successful trades reset the accept status before closing
        if tradeWasCompleted then
            DebugPrint("Trade closed after completion - recording trade")
            RecordTrade()
        else
            DebugPrint("Trade cancelled")
        end
        
        -- Reset state
        currentTrade = { playerItems = {}, playerGold = 0, targetItems = {}, targetGold = 0, targetName = "Unknown" }
        completedTrade = nil  -- Clear the completed trade data
        playerAccepted = false
        targetAccepted = false
        tradeWasCompleted = false  -- Reset the completion flag
    end
end)

-- Create improved trade history window
local function ShowTradeHistory()
    if not TradeLoggerDB then
        TradeLoggerDB = { trades = {}, trackGold = true, trackItems = true }
    end
    if not TradeLoggerDB.trades then
        TradeLoggerDB.trades = {}
    end
    
    if TradeLoggerHistoryFrame then
        TradeLoggerHistoryFrame:Show()
        return
    end

    local f = CreateFrame("Frame", "TradeLoggerHistoryFrame", UIParent)
    f:SetSize(700, 500)
    f:SetPoint("CENTER")
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 8, right = 8, top = 8, bottom = 8 }
    })
    f:SetBackdropColor(0, 0, 0, 0.9)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetFrameStrata("DIALOG")

    -- Title
    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.title:SetPoint("TOP", 0, -15)
    f.title:SetText("|cFFFFD700Trade History|r")

    -- Subtitle
    f.subtitle = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.subtitle:SetPoint("TOP", f.title, "BOTTOM", 0, -5)
    f.subtitle:SetText("Showing last " .. math.min(50, #TradeLoggerDB.trades) .. " trades")
    f.subtitle:SetTextColor(0.7, 0.7, 0.7)

    -- Scroll frame
    local scrollFrame = CreateFrame("ScrollFrame", "TradeLoggerScrollFrame", f)
    scrollFrame:SetPoint("TOPLEFT", 15, -55)
    scrollFrame:SetPoint("BOTTOMRIGHT", -35, 45)
    
    -- Scroll bar
    local scrollBar = CreateFrame("Slider", "TradeLoggerScrollBar", scrollFrame, "UIPanelScrollBarTemplate")
    scrollBar:SetPoint("TOPLEFT", scrollFrame, "TOPRIGHT", 0, -16)
    scrollBar:SetPoint("BOTTOMLEFT", scrollFrame, "BOTTOMRIGHT", 0, 16)
    scrollBar:SetMinMaxValues(0, 0)
    scrollBar:SetValueStep(1)
    scrollFrame.scrollBar = scrollBar

    local content = CreateFrame("Frame", "TradeLoggerContent", scrollFrame)
    content:SetSize(640, 1)
    scrollFrame:SetScrollChild(content)
    
    -- Scroll handling
    scrollBar:SetScript("OnValueChanged", function(self, value)
        scrollFrame:SetVerticalScroll(value)
    end)
    
    scrollFrame:SetScript("OnMouseWheel", function(self, delta)
        local current = scrollBar:GetValue()
        local min, max = scrollBar:GetMinMaxValues()
        if delta > 0 then
            scrollBar:SetValue(math.max(min, current - 30))
        else
            scrollBar:SetValue(math.min(max, current + 30))
        end
    end)
    
    scrollFrame:EnableMouseWheel(true)

    -- Background for content (WoTLK compatible)
    local contentBg = content:CreateTexture(nil, "BACKGROUND")
    contentBg:SetAllPoints()
    contentBg:SetTexture(0, 0, 0, 0.3)

    -- Populate trade history with improved formatting
    local yOffset = -10
    local maxTrades = math.min(50, #TradeLoggerDB.trades)
    
    if maxTrades == 0 then
        local noTradesText = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        noTradesText:SetPoint("TOP", 0, -20)
        noTradesText:SetText("|cFF808080No trades recorded yet.|r")
    else
        for i = 1, maxTrades do
            local trade = TradeLoggerDB.trades[i]
            if trade then
                -- Create frame for this trade entry
                local tradeFrame = CreateFrame("Frame", nil, content)
                tradeFrame:SetPoint("TOPLEFT", 10, yOffset)
                tradeFrame:SetPoint("RIGHT", -10, 0)
                tradeFrame:SetHeight(60) -- Will adjust based on content
                
                -- Alternating background (WoTLK compatible)
                if i % 2 == 0 then
                    local bg = tradeFrame:CreateTexture(nil, "BACKGROUND")
                    bg:SetAllPoints()
                    bg:SetTexture(1, 1, 1, 0.03)
                end
                
                -- Trade header with time and partner
                local header = tradeFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
                header:SetPoint("TOPLEFT", 5, -5)
                header:SetText(string.format("|cFFFFD700[%s]|r Trade with |cFF00FFFF%s|r", 
                    trade.time or "Unknown", 
                    trade.target or "Unknown"))
                
                local lineOffset = -25
                local tradeHeight = 30
                
                -- Format "You gave" section (arrow pointing right)
                local gaveItems = {}
                if trade.playerItems then
                    for _, item in pairs(trade.playerItems) do
                        if item then table.insert(gaveItems, item) end
                    end
                end
                
                if #gaveItems > 0 or (trade.playerGold and trade.playerGold > 0) then
                    local gaveText = tradeFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    gaveText:SetPoint("TOPLEFT", 15, lineOffset)
                    
                    local gaveString = "|cFFFF6060You gave:|r "
                    if #gaveItems > 0 then
                        gaveString = gaveString .. table.concat(gaveItems, ", ")
                    end
                    if trade.playerGold and trade.playerGold > 0 then
                        if #gaveItems > 0 then gaveString = gaveString .. ", " end
                        gaveString = gaveString .. GetCoinTextureString(trade.playerGold)
                    end
                    
                    gaveText:SetText(gaveString)
                    gaveText:SetWidth(600)
                    gaveText:SetJustifyH("LEFT")
                    lineOffset = lineOffset - 18
                    tradeHeight = tradeHeight + 18
                end
                
                -- Format "You received" section (arrow pointing left)
                local gotItems = {}
                if trade.targetItems then
                    for _, item in pairs(trade.targetItems) do
                        if item then table.insert(gotItems, item) end
                    end
                end
                
                if #gotItems > 0 or (trade.targetGold and trade.targetGold > 0) then
                    local gotText = tradeFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    gotText:SetPoint("TOPLEFT", 15, lineOffset)
                    
                    local gotString = "|cFF60FF60You received:|r "
                    if #gotItems > 0 then
                        gotString = gotString .. table.concat(gotItems, ", ")
                    end
                    if trade.targetGold and trade.targetGold > 0 then
                        if #gotItems > 0 then gotString = gotString .. ", " end
                        gotString = gotString .. GetCoinTextureString(trade.targetGold)
                    end
                    
                    gotText:SetText(gotString)
                    gotText:SetWidth(600)
                    gotText:SetJustifyH("LEFT")
                    lineOffset = lineOffset - 18
                    tradeHeight = tradeHeight + 18
                end
                
                -- If nothing was traded (shouldn't happen with new logic, but just in case)
                if #gaveItems == 0 and #gotItems == 0 and 
                   (not trade.playerGold or trade.playerGold == 0) and 
                   (not trade.targetGold or trade.targetGold == 0) then
                    local emptyText = tradeFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                    emptyText:SetPoint("TOPLEFT", 15, lineOffset)
                    emptyText:SetText("|cFF808080(Empty trade)|r")
                    tradeHeight = tradeHeight + 18
                end
                
                -- Separator line (WoTLK compatible)
                local separator = tradeFrame:CreateTexture(nil, "OVERLAY")
                separator:SetPoint("BOTTOMLEFT", 0, 0)
                separator:SetPoint("BOTTOMRIGHT", 0, 0)
                separator:SetHeight(1)
                separator:SetTexture(0.3, 0.3, 0.3, 0.5)
                
                tradeFrame:SetHeight(tradeHeight + 10)
                yOffset = yOffset - tradeHeight - 15
            end
        end
    end
    
    content:SetHeight(math.abs(yOffset) + 20)
    
    -- Update scroll range
    local contentHeight = math.abs(yOffset) + 20
    local frameHeight = scrollFrame:GetHeight()
    if contentHeight > frameHeight then
        scrollBar:SetMinMaxValues(0, contentHeight - frameHeight)
        scrollBar:Show()
    else
        scrollBar:SetMinMaxValues(0, 0)
        scrollBar:Hide()
    end

    -- Button frame at bottom
    local buttonFrame = CreateFrame("Frame", nil, f)
    buttonFrame:SetPoint("BOTTOMLEFT", 15, 10)
    buttonFrame:SetPoint("BOTTOMRIGHT", -15, 10)
    buttonFrame:SetHeight(30)

    -- Close button
    local closeBtn = CreateFrame("Button", nil, buttonFrame, "UIPanelButtonTemplate")
    closeBtn:SetSize(80, 22)
    closeBtn:SetPoint("CENTER", 0, 0)
    closeBtn:SetText("Close")
    closeBtn:SetScript("OnClick", function()
        f:Hide()
    end)
    
    -- Options button
    local optionsBtn = CreateFrame("Button", nil, buttonFrame, "UIPanelButtonTemplate")
    optionsBtn:SetSize(80, 22)
    optionsBtn:SetPoint("RIGHT", closeBtn, "LEFT", -10, 0)
    optionsBtn:SetText("Options")
    optionsBtn:SetScript("OnClick", function()
        OpenOptions()
    end)
    
    -- Clear button
    local clearBtn = CreateFrame("Button", nil, buttonFrame, "UIPanelButtonTemplate")
    clearBtn:SetSize(80, 22)
    clearBtn:SetPoint("LEFT", closeBtn, "RIGHT", 10, 0)
    clearBtn:SetText("Clear All")
    clearBtn:SetScript("OnClick", function()
        StaticPopup_Show("TRADELOGGER_CLEAR_CONFIRM")
    end)

    f:Show()
end

-- Confirmation dialog for clearing trades
StaticPopupDialogs["TRADELOGGER_CLEAR_CONFIRM"] = {
    text = "Are you sure you want to clear all trade history?",
    button1 = "Yes",
    button2 = "No",
    OnAccept = function()
        TradeLoggerDB.trades = {}
        if TradeLoggerHistoryFrame then
            TradeLoggerHistoryFrame:Hide()
            TradeLoggerHistoryFrame = nil
        end
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD700TradeLogger:|r Trade history cleared.", 1, 0.8, 0)
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}

-- Options frame
function OpenOptions()
    if TradeLoggerOptionsFrame then
        TradeLoggerOptionsFrame:Show()
        return
    end

    local f = CreateFrame("Frame", "TradeLoggerOptionsFrame", UIParent)
    f:SetSize(300, 200)
    f:SetPoint("CENTER")
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 8, right = 8, top = 8, bottom = 8 }
    })
    f:SetBackdropColor(0, 0, 0, 1)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetFrameStrata("DIALOG")

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.title:SetPoint("TOP", 0, -15)
    f.title:SetText("TradeLogger Options")

    -- Track Gold Checkbox
    local goldCheck = CreateFrame("CheckButton", nil, f, "InterfaceOptionsCheckButtonTemplate")
    goldCheck:SetPoint("TOPLEFT", 30, -50)
    goldCheck:SetChecked(TradeLoggerDB.trackGold)
    goldCheck:SetScript("OnClick", function(self)
        TradeLoggerDB.trackGold = self:GetChecked()
    end)
    
    local goldText = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    goldText:SetPoint("LEFT", goldCheck, "RIGHT", 5, 0)
    goldText:SetText("Track Gold Exchanges")

    -- Track Items Checkbox
    local itemsCheck = CreateFrame("CheckButton", nil, f, "InterfaceOptionsCheckButtonTemplate")
    itemsCheck:SetPoint("TOPLEFT", 30, -80)
    itemsCheck:SetChecked(TradeLoggerDB.trackItems)
    itemsCheck:SetScript("OnClick", function(self)
        TradeLoggerDB.trackItems = self:GetChecked()
    end)
    
    local itemsText = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    itemsText:SetPoint("LEFT", itemsCheck, "RIGHT", 5, 0)
    itemsText:SetText("Track Item Exchanges")

    -- Debug mode checkbox
    local debugCheck = CreateFrame("CheckButton", nil, f, "InterfaceOptionsCheckButtonTemplate")
    debugCheck:SetPoint("TOPLEFT", 30, -110)
    debugCheck:SetChecked(false)
    debugCheck:SetScript("OnClick", function(self)
        if self:GetChecked() then
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD700TradeLogger:|r Debug mode enabled", 1, 0.8, 0)
            -- Redefine DebugPrint to actually print
            DebugPrint = function(msg)
                DEFAULT_CHAT_FRAME:AddMessage("|cFF808080[TL Debug]: " .. msg .. "|r")
            end
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD700TradeLogger:|r Debug mode disabled", 1, 0.8, 0)
            -- Disable debug printing
            DebugPrint = function(msg) end
        end
    end)
    
    local debugText = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    debugText:SetPoint("LEFT", debugCheck, "RIGHT", 5, 0)
    debugText:SetText("Debug Mode")

    -- Info text
    local infoText = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    infoText:SetPoint("BOTTOM", 0, 45)
    infoText:SetText("|cFF808080Changes apply to new trades only|r")

    -- Close button
    local closeBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    closeBtn:SetSize(80, 22)
    closeBtn:SetPoint("BOTTOM", 0, 15)
    closeBtn:SetText("Close")
    closeBtn:SetScript("OnClick", function()
        f:Hide()
    end)

    f:Show()
end

-- Slash commands
SLASH_TRADELOGGER1 = "/tradelog"
SLASH_TRADELOGGER2 = "/tl"

SlashCmdList["TRADELOGGER"] = function(msg)
    msg = msg:lower()
    if msg == "options" or msg == "opt" then
        OpenOptions()
    elseif msg == "clear" then
        StaticPopup_Show("TRADELOGGER_CLEAR_CONFIRM")
    elseif msg == "help" then
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD700TradeLogger Commands:|r", 1, 0.8, 0)
        DEFAULT_CHAT_FRAME:AddMessage("  |cFF00FF00/tradelog|r or |cFF00FF00/tl|r - Open trade history", 1, 1, 1)
        DEFAULT_CHAT_FRAME:AddMessage("  |cFF00FF00/tradelog options|r - Open options", 1, 1, 1)
        DEFAULT_CHAT_FRAME:AddMessage("  |cFF00FF00/tradelog clear|r - Clear all trade history", 1, 1, 1)
        DEFAULT_CHAT_FRAME:AddMessage("  |cFF00FF00/tradelog help|r - Show this help", 1, 1, 1)
    elseif msg == "test" then
        -- Add a test trade for debugging
        if not TradeLoggerDB.trades then TradeLoggerDB.trades = {} end
        table.insert(TradeLoggerDB.trades, 1, {
            time = date("%m/%d %H:%M"),
            target = "TestPlayer",
            playerItems = {[1] = "|cff0070dd|Hitem:12345:0:0:0:0:0:0:0|h[Test Item]|h|r x5"},
            playerGold = 50000,
            targetItems = {[1] = "|cffa335ee|Hitem:54321:0:0:0:0:0:0:0|h[Epic Test Item]|h|r"},
            targetGold = 10000,
            playerName = playerName
        })
        DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD700TradeLogger:|r Test trade added", 1, 0.8, 0)
    else
        ShowTradeHistory()
    end
end

-- Initial message
DEFAULT_CHAT_FRAME:AddMessage("|cFFFFD700TradeLogger v2.1|r loaded - Type |cFF00FF00/tradelog|r to view history", 1, 0.8, 0)