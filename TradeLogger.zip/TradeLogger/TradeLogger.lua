-- SavedVariables
TradeLoggerDB = TradeLoggerDB or {}
TradeLoggerSettings = TradeLoggerSettings or { trackGold = true, numberedItems = true }

-- Current trade data
local tradeData = {
    playerItems = {},
    targetItems = {},
    playerMoney = 0,
    targetMoney = 0,
    targetName = "",
    accepted = false,
}

-- Helper functions
local function ResetTradeData()
    tradeData = {
        playerItems = {},
        targetItems = {},
        playerMoney = 0,
        targetMoney = 0,
        targetName = "",
        accepted = false,
    }
end

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[TradeLogger]|r " .. msg)
end

-- Convert copper to gold/silver/copper with icons
local function GetCoinString(copper)
    if copper == 0 then return "0|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t" end
    local gold = math.floor(copper / 10000)
    local silver = math.floor((copper % 10000) / 100)
    local copperLeft = copper % 100
    local parts = {}
    if gold > 0 then table.insert(parts, gold .. "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t") end
    if silver > 0 then table.insert(parts, silver .. "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t") end
    if copperLeft > 0 then table.insert(parts, copperLeft .. "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t") end
    return table.concat(parts, " ")
end

local function FormatItems(items)
    if TradeLoggerSettings.numberedItems then
        local lines = {}
        for i, item in ipairs(items) do
            table.insert(lines, i .. ". " .. item)
        end
        return table.concat(lines, ", ")
    else
        return table.concat(items, ", ")
    end
end

-- Event handling
local f = CreateFrame("Frame")
f:RegisterEvent("TRADE_SHOW")
f:RegisterEvent("TRADE_PLAYER_ITEM_CHANGED")
f:RegisterEvent("TRADE_TARGET_ITEM_CHANGED")
f:RegisterEvent("TRADE_MONEY_CHANGED")
f:RegisterEvent("TRADE_ACCEPT_UPDATE")
f:RegisterEvent("TRADE_CLOSED")

f:SetScript("OnEvent", function(self, event, arg1, arg2)
    if event == "TRADE_SHOW" then
        ResetTradeData()
        tradeData.targetName = UnitName("NPC") or UnitName("target") or "Unknown"
    elseif event == "TRADE_PLAYER_ITEM_CHANGED" then
        tradeData.playerItems = {}
        for i = 1, 6 do
            local name, _, quantity = GetTradePlayerItemInfo(i)
            if name then table.insert(tradeData.playerItems, quantity .. "x " .. name) end
        end
    elseif event == "TRADE_TARGET_ITEM_CHANGED" then
        tradeData.targetItems = {}
        for i = 1, 6 do
            local name, _, quantity = GetTradeTargetItemInfo(i)
            if name then table.insert(tradeData.targetItems, quantity .. "x " .. name) end
        end
    elseif event == "TRADE_MONEY_CHANGED" then
        tradeData.playerMoney = GetPlayerTradeMoney()
        tradeData.targetMoney = GetTargetTradeMoney()
    elseif event == "TRADE_ACCEPT_UPDATE" then
        if arg1 == 1 and arg2 == 1 then tradeData.accepted = true end
    elseif event == "TRADE_CLOSED" then
        if not tradeData.accepted then return end

        local entry = {
            time = date("%Y-%m-%d %H:%M:%S"),
            target = tradeData.targetName,
            playerItems = tradeData.playerItems,
            targetItems = tradeData.targetItems,
            playerMoney = tradeData.playerMoney,
            targetMoney = tradeData.targetMoney,
        }

        table.insert(TradeLoggerDB, entry)

        -- Chat output
        Print("Trade with " .. entry.target .. " at " .. entry.time)
        if #entry.playerItems > 0 then Print("  You gave items: " .. FormatItems(entry.playerItems)) end
        if TradeLoggerSettings.trackGold and entry.playerMoney > 0 then Print("  You gave money: " .. GetCoinString(entry.playerMoney)) end
        if #entry.targetItems > 0 then Print("  You received items: " .. FormatItems(entry.targetItems)) end
        if TradeLoggerSettings.trackGold and entry.targetMoney > 0 then Print("  You received money: " .. GetCoinString(entry.targetMoney)) end
        if TradeLoggerSettings.trackGold then Print("  Net gold: " .. GetCoinString(entry.targetMoney - entry.playerMoney)) end
    end
end)

-- Options frame
local function CreateOptionsFrame()
    if TradeLoggerOptions then return end
    local f = CreateFrame("Frame", "TradeLoggerOptions", UIParent)
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    })
    f:SetBackdropColor(0, 0, 0, 1)
    f:SetSize(250, 120)
    f:SetPoint("CENTER")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.title:SetPoint("TOP", f, "TOP", 0, -10)
    f.title:SetText("TradeLogger Options")

    -- Close button
    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -5, -5)
    closeBtn:SetScript("OnClick", function() f:Hide() end)

    local trackGold = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
    trackGold:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -30)
    trackGold:SetChecked(TradeLoggerSettings.trackGold)
    trackGold:SetScript("OnClick", function(self) TradeLoggerSettings.trackGold = self:GetChecked() end)
    trackGold.label = trackGold:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    trackGold.label:SetPoint("LEFT", trackGold, "RIGHT", 5, 0)
    trackGold.label:SetText("Track gold")

    local numberedItems = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
    numberedItems:SetPoint("TOPLEFT", trackGold, "BOTTOMLEFT", 0, -10)
    numberedItems:SetChecked(TradeLoggerSettings.numberedItems)
    numberedItems:SetScript("OnClick", function(self) TradeLoggerSettings.numberedItems = self:GetChecked() end)
    numberedItems.label = numberedItems:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    numberedItems.label:SetPoint("LEFT", numberedItems, "RIGHT", 5, 0)
    numberedItems.label:SetText("Numbered items")

    f:Hide()
end

-- Pop-up log window
local function CreateLogWindow()
    if TradeLoggerFrame then return end
    local f = CreateFrame("Frame", "TradeLoggerFrame", UIParent)
    f:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    })
    f:SetBackdropColor(0, 0, 0, 1)
    f:SetSize(400, 300)
    f:SetPoint("CENTER")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.title:SetPoint("TOP", f, "TOP", 0, -10)
    f.title:SetText("Trade Logger")

    -- Close button
    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -5, -5)
    closeBtn:SetScript("OnClick", function() f:Hide() end)

    local scroll = CreateFrame("ScrollFrame", "TradeLoggerScrollFrame", f, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -30)
    scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -30, 10)

    local editBox = CreateFrame("EditBox", "TradeLoggerEditBox", scroll)
    editBox:SetMultiLine(true)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetWidth(360)
    editBox:SetAutoFocus(false)
    editBox:SetMaxLetters(99999)
    editBox:SetText("")
    scroll:SetScrollChild(editBox)

    f.scroll = scroll
    f.editBox = editBox
    f:Hide()
end

-- Show last N trades in pop-up
local function ShowTradesInWindow(num)
    CreateLogWindow()
    local text = ""
    for i = math.max(1, #TradeLoggerDB - num + 1), #TradeLoggerDB do
        local entry = TradeLoggerDB[i]
        text = text .. entry.time .. " with " .. entry.target .. "\n"
        if #entry.playerItems > 0 then text = text .. "  You gave items: " .. FormatItems(entry.playerItems) .. "\n" end
        if TradeLoggerSettings.trackGold and entry.playerMoney > 0 then text = text .. "  You gave money: " .. GetCoinString(entry.playerMoney) .. "\n" end
        if #entry.targetItems > 0 then text = text .. "  You received items: " .. FormatItems(entry.targetItems) .. "\n" end
        if TradeLoggerSettings.trackGold and entry.targetMoney > 0 then text = text .. "  You received money: " .. GetCoinString(entry.targetMoney) .. "\n" end
        if TradeLoggerSettings.trackGold then text = text .. "  Net gold: " .. GetCoinString(entry.targetMoney - entry.playerMoney) .. "\n" end
        text = text .. "\n"
    end

    TradeLoggerFrame.editBox:SetText(text)
    TradeLoggerFrame:Show()
end

-- Slash command
SLASH_TRADELOGGER1 = "/tradelog"
SlashCmdList["TRADELOGGER"] = function(msg)
    msg = msg:lower()
    if msg == "options" then
        CreateOptionsFrame()
        TradeLoggerOptions:Show()
    else
        ShowTradesInWindow(50) -- always show last 50 trades
    end
end
